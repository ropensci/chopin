## -----------------------------------------------------------------------------
knitr::opts_chunk$set(warning = FALSE, message = FALSE)


## -----------------------------------------------------------------------------
library(scomps)
library(sf)
library(terra)
library(stars)
library(dplyr)


## -----------------------------------------------------------------------------
# your_grid = scomps::sp_index_grid()


## -----------------------------------------------------------------------------
# library(mapsf)
# mf_map(your_grid$geometry)



