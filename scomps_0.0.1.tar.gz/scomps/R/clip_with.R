# Generated from litr_package_template.rmd: do not edit by hand

#' Clip with a polygon (to be written)
#' 
#' @param x 
#' @param poly 
#' @return 
#' @description 
#' @author Insang Song \email{geoissong@@gmail.com}
#' @examples 
#' # data
#' 
#' # run
#' clip_with()
#' 
#' @export 
clip_with <- function(x, poly, ...) {

}

